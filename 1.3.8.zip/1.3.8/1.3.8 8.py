from random import randint

def goguess():
    print "The winning number is a number between 1 and 20 inclusive"
    winner = randint(1,20)
    guess = int(raw_input('Guess: '))
    while guess!= winner:
        if guess < winner:
            print 'Sorry, your guess was too low.'
        else:
            print 'Sorry, your guess was too high.'
        guess = int(raw_input('Next guess: '))  
    print 'Right! You guessed correctly!'