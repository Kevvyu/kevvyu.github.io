from __future__ import print_function
import random

def guess_winner(players=('Amy', 'Bill', 'Cathy', 'Dale')):
    '''guess winner is defined as 4 certain players
 
   The definition of guess winner is a list.
    '''
    winner = random.choice(players) 

    ##The code randomly chooses a player to win the lottery from the defined term.
    print('Guess which of these people won the lottery: ',end='')
    for p in players[:len(players)-1]: #It will return the length/amount of players then subtract it by one.
        print(p+', ', end='')
    print(players[len(players)-1]) #It then tells you that number that it returned.

 ##Everytime you guess the wrong winner it will tell you to guess again. If you guessed it right, it will tell you that you guessed correctly.
    guesses = 1 
    while raw_input() != winner:
     print('Guess again!')
     guesses += 1
    print('You guessed in', guesses, 'guesses!')
    return guesses    