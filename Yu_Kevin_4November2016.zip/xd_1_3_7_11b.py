import random

def matches(ticket, winners):
    matching=0
    y=0
    for choices in winners:
        if ticket[y] in winners:
            matching+=1
        else:
            matching+=0
        y+=1
    return matching
    