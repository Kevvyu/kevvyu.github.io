import random

def report(guess, secret):
    matching=0
    y=0
    for a in secret:
        if guess[y] in secret[y]:
            matching+=1
        else:
            matching+=0
        y+=1
    return [matching, len(secret)-matching]