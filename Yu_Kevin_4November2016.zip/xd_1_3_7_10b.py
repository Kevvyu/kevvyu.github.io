import random

def dice(n):
    dice=[1,2,3,4,5,6]
    finalroll=0
    for choices in range(n):
        d1=random.choice(dice)
        finalroll+=d1
    return finalroll