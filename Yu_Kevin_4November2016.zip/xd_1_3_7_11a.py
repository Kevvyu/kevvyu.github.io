def hangman_display(guessed, secret):
    y=0
    alphabet='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    slist=list(secret)
    output = ''
    for x in slist:
        if slist[y] in alphabet:
            if slist[y] in guessed:
                slist[y]=slist[y]
            else:
                slist[y]='-'
        else:
            slist[y]=' '
        y+=1
    for x in slist:
        output+=x
    return output